Prerequisites
- Create virtual environment
python3 -m venv mlops_env
- Activate virtual environment
source mlops_env/bin/activate
- Install requirements
python3 -m pip install -r requirements.txt

Start the API
uvicorn quiz_api_main:api --reload

Test the API using quiz_api_text.ipynb